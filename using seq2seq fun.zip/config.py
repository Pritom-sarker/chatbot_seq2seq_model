from sklearn.externals import joblib
import numpy as np
import sys


x=joblib.load('data/final_input.pkl')
y=joblib.load('data/final_output.pkl')

x=np.array(x)
y=np.array(y)

char2num=joblib.load('data/char2num.pkl')


x_seq_length = len(x[0])
y_seq_length = len(y[0])- 1

if x_seq_length!=y_seq_length:
    sys.exit()


#Peramiter for train and test

batch_size =128
sequence_length =x_seq_length
hidden_size=256
num_layers=2
symbols=len(char2num)
embedding_size=256
learning_rate=0.001

#peramiter for clean data
lines=1500
limit=30


