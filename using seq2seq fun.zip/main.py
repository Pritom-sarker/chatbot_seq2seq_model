import os
import config as con


train='new' #old/test

if train=='new':
    print('Delete old saved model and change in config file :D')

    os.system('python clean_data.py')
    os.system('python prepare_data.py')
    os.system('python model.py')


elif train=='test':
    os.system('python test.py')

elif train=='old':
    os.system('python test.py')