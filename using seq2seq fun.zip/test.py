import tensorflow as tf
import numpy as np
from sklearn.externals import joblib
import My_Dl_lib as mdl
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import os
import time
import config as  con

tf.reset_default_graph()


char2num=joblib.load('data/char2num.pkl')
max_len_x=con.sequence_length


im='i am fine'


x=[]
x.append(im.split())

x = [[char2num['<PAD>']]*(max_len_x - len(date)) +[char2num[x_] for x_ in date] for date in x]



#--------------------------- Peramiter------------

batch_size =con.batch_size
sequence_length = con.sequence_length
hidden_size = con.hidden_size
num_layers = con.num_layers
num_encoder_symbols = con.symbols
num_decoder_symbols = con.symbols
embedding_size = con.embedding_size
learning_rate =con.learning_rate




with tf.device('/cpu:0'):
    #Built a Model
    encoder_inputs = tf.placeholder(dtype=tf.int32, shape=[None, sequence_length])
    decoder_inputs = tf.placeholder(dtype=tf.int32, shape=[None, sequence_length])

    targets = tf.placeholder(dtype=tf.int32, shape=[None, sequence_length])
    weights = tf.placeholder(dtype=tf.float32, shape=[None, sequence_length])

    cell = tf.nn.rnn_cell.BasicLSTMCell(hidden_size)
    cell = tf.nn.rnn_cell.MultiRNNCell([cell] * num_layers)

    results, states = tf.contrib.legacy_seq2seq.embedding_rnn_seq2seq(
        tf.unstack(encoder_inputs, axis=1),
        tf.unstack(decoder_inputs, axis=1),
        cell,
        num_encoder_symbols,
        num_decoder_symbols,
        embedding_size,
        feed_previous=True
    )
    logits = tf.stack(results, axis=1)


    pred = tf.argmax(logits, axis=2)


if __name__=='__main__':
    gpu_options = tf.GPUOptions(allow_growth=True)
    sess = tf.InteractiveSession(config=tf.ConfigProto(gpu_options=gpu_options))

    saver = tf.train.Saver(save_relative_paths=True)

    train_weights = np.ones(shape=[batch_size, sequence_length], dtype=np.float32)

    mdl._check_restore_parameters(sess, saver)

    sess.run(tf.global_variables_initializer())

    decoder_input = np.zeros([1, sequence_length])

    ans=sess.run(pred,feed_dict={encoder_inputs:x,
                                 weights:train_weights,
                                 decoder_inputs:decoder_input})
    ans=np.array(ans)
    print(ans.shape)
    sent=""
    num2char = joblib.load('data/num2char.pkl')
    for i in range(0,len(ans[0])):
        sent+=num2char[ans[0][i]]+" "

    print(sent)