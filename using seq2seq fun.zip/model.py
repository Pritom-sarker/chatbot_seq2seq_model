import tensorflow as tf
import numpy as np
from sklearn.externals import joblib
import My_Dl_lib as mdl
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import os
import time
import config as  con

x=joblib.load('data/final_input.pkl')
y=joblib.load('data/final_output.pkl')

x=np.array(x)
y=np.array(y)

char2num=joblib.load('data/char2num.pkl')


x_seq_length = len(x[0])
y_seq_length = len(y[0])- 1

print(x_seq_length,y_seq_length)

#--------------------------- Peramiter------------

batch_size =con.batch_size
sequence_length = con.sequence_length
hidden_size = con.hidden_size
num_layers = con.num_layers
num_encoder_symbols = con.symbols
num_decoder_symbols = con.symbols
embedding_size = con.embedding_size
learning_rate =con.learning_rate






with tf.device('/device:GPU:0'):
    #Built a Model
    encoder_inputs = tf.placeholder(dtype=tf.int32, shape=[None, sequence_length])
    decoder_inputs = tf.placeholder(dtype=tf.int32, shape=[None, sequence_length])

    targets = tf.placeholder(dtype=tf.int32, shape=[None, sequence_length])
    weights = tf.placeholder(dtype=tf.float32, shape=[None, sequence_length])

    cell = tf.nn.rnn_cell.BasicLSTMCell(hidden_size)
    cell = tf.nn.rnn_cell.MultiRNNCell([cell] * num_layers)

    results, states = tf.contrib.legacy_seq2seq.embedding_rnn_seq2seq(
        tf.unstack(encoder_inputs, axis=1),
        tf.unstack(decoder_inputs, axis=1),
        cell,
        num_encoder_symbols,
        num_decoder_symbols,
        embedding_size,
        feed_previous=False
    )
    logits = tf.stack(results, axis=1)
    loss = tf.contrib.seq2seq.sequence_loss(logits, targets=targets, weights=weights)
    pred = tf.argmax(logits, axis=2)

    train_op = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(loss)


    # acc,acc_op=tf.metrics.accuracy(labels=tf.argmax(targets, 1),
    #                               predictions=tf.argmax(logits,1))







if __name__=="__main__":
    #Training Part ----------->>
    train_weights = np.ones(shape=[batch_size, sequence_length], dtype=np.float32)

    sess = tf.Session(config=tf.ConfigProto(
          allow_soft_placement=True, log_device_placement=True))




    saver = tf.train.Saver(save_relative_paths=True)

    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.050, random_state=42)

    print("Training Element : {} ".format(len(X_train)))
    print("Test Element  : {} ".format(len(y_test)))

    sess.run(tf.global_variables_initializer())

    mdl._check_restore_parameters(sess, saver)

    a=[]

    epochs = 10000
    for epoch_i in range(epochs):
        start_time = time.time()
        for batch_i in range(0,int(len(X_train)/batch_size)):
            source_batch, target_batch=mdl.getBatch(batch_i, batch_size,X_train, y_train)
            _,losss  = sess.run([train_op,loss],
                feed_dict = {encoder_inputs: source_batch,
                 decoder_inputs: target_batch[:, :-1], # without last element
                 targets: target_batch[:, 1:],
                             weights:train_weights}) # with out first element

            batch_logits = sess.run(logits, feed_dict={encoder_inputs:source_batch,
                                                       decoder_inputs: target_batch[:, :-1]})

            accuracy = np.mean(batch_logits.argmax(axis=-1) == target_batch[:, 1:])

            print("Traning -- Loss -> {} Accuracy -> {} % ".format(losss,accuracy*100))
        batch_logits = sess.run(logits, feed_dict={encoder_inputs: X_test ,
                                                   decoder_inputs: y_test[:, :-1]})

        accuracy = np.mean(batch_logits.argmax(axis=-1) == y_test[:, 1:])
        a.append(accuracy)
        print("step -> {} || accuracy-> {} % for test set".format(epoch_i,accuracy * 100))
        if (epoch_i % 2 == 0):

            saver.save(sess, 'final_model/my_test_model',global_step=epoch_i)
            print("------- >> Model saved")

        # if (epoch_i%25==0):
        #     plt.clf()
        #     plt.plot(a)
        #     plt.title("Accuracy curve ")
        #     plt.xlabel("Accuracy")
        #     plt.xlabel("Iteration")
        #
        #     plt.savefig("curve/accuracy for Train set-{}.jpg".format(len(X_train)))
